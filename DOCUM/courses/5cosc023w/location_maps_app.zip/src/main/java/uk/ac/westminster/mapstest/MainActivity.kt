package uk.ac.westminster.mapstest

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import java.util.*

class MainActivity : AppCompatActivity() {
    lateinit var tv: TextView
    lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    lateinit var lastLocation: Location
    lateinit var locationCallback: LocationCallback

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tv = findViewById(R.id.tv)

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

        val bt = findViewById<Button>(R.id.bt)
        bt.setOnClickListener {
            getLocation()
        }

        val sMap = findViewById<Button>(R.id.sMap)
        sMap.setOnClickListener {
            showMap()
        }

        locationCallback = object: LocationCallback() {
            override fun onLocationResult(loc: LocationResult) {
                super.onLocationResult(loc)
                lastLocation = loc.lastLocation
                displayLastLocation()
            }
        }
    }


    fun showMap() {
        var i = Intent(this, MapsActivity::class.java)
        i.putExtra("longitude", lastLocation.longitude)
        i.putExtra("latitude", lastLocation.latitude)
        startActivity(i)
    }

    fun displayLastLocation() {
        if (lastLocation != null) {
            var address: Address? = null

            var geocoder: Geocoder = Geocoder(this, Locale.getDefault())
            var addresses: List<Address> =
                geocoder.getFromLocation(lastLocation.latitude, lastLocation.longitude, 1)

            if (addresses != null && addresses.size > 0) {
                address = addresses[0]
            }

            tv.setText("Latitude: " + lastLocation.latitude + ", Longitude: " + lastLocation.longitude)
            if (address != null)
                tv.append(address.toString())
        } else
            tv.setText("Location is not available")
    }



    fun getLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            // if the permission is not granted, request the permission
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                1
            )
        }
        else {  // permission is already granted
            //getLastLocation()
            fusedLocationProviderClient.requestLocationUpdates(getLocationRequest(), locationCallback, Looper.getMainLooper())
        }
    }

    fun getLocationRequest(): LocationRequest {
        val locationRequest = LocationRequest.create()
        locationRequest.setInterval(10000L)
        locationRequest.setFastestInterval(5000L)
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)

        return locationRequest
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            getLastLocation()
    }

    fun getLastLocation() {
          fusedLocationProviderClient.lastLocation.addOnSuccessListener { location->
              if (location != null) {
                  lastLocation = location
                  var address: Address? = null

                  var geocoder: Geocoder = Geocoder(this, Locale.getDefault())
                  var addresses: List<Address> =
                      geocoder.getFromLocation(lastLocation.latitude, lastLocation.longitude, 1)

                  if (addresses != null && addresses.size > 0) {
                      address = addresses[0]
                  }

                  tv.setText("Latitude: " + lastLocation.latitude + ", Longitude: " + lastLocation.longitude)
                  if (address != null)
                      tv.append(address.toString())
              }
              else
                  tv.setText("Location is not available")

          }
    }

}