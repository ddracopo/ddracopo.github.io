package com.example.tictactoe_composableapp

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.toMutableStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp


// dimensions of the board
val rows = 3
val cols = 3

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GUI()
        }
    }
}

@Preview
@Composable
fun GUI() {
    var grid = remember{MutableList(rows*cols) {i -> ' '}.toMutableStateList()}
    var gameIsPlayable by remember{ mutableStateOf(true) }

    Column(modifier = Modifier
        .fillMaxSize()
        .padding(top = 100.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(0.dp)) {

        val context = LocalContext.current
        // create 3 rows of buttons
        for (r in 0..rows-1) {
            Row {
                // each row has 3 buttons (columns)
                for (c in 0..cols-1) {
                    var index = r*rows + c
                    Button(shape = RectangleShape,
                           colors = ButtonDefaults.buttonColors(containerColor = colorResource(id = R.color.yellow)),
                           modifier = Modifier
                               .size(width = 80.dp, height = 80.dp)
                               .padding(1.dp),
                           enabled = gameIsPlayable,
                           onClick = {
                               // human move
                               if (grid[index] == ' ') {
                                   grid[index] = 'X'

                                   val winner = checkWinner(grid)
                                   if (winner == 'X' || winner == 'O') {
                                       displayGameOver(winner, context)
                                       gameIsPlayable = false
                                   }
                                   else {
                                       // now it is the turn of the computer player.
                                       // Initially this is a naive player choosing
                                       // a random cell among the available ones
                                       var chosen_cell = ComputerMove(grid)
                                       if (chosen_cell != -1) {  // if board is not full play the move
                                           grid[chosen_cell] = 'O'

                                           val winner = checkWinner(grid)
                                           if (winner == 'X' || winner == 'O') {
                                               displayGameOver(winner, context)
                                               gameIsPlayable = false
                                           }
                                       }
                                       else {
                                           displayGameOver('-', context)
                                           gameIsPlayable = false
                                       }
                                   }
                               }
                               else
                                   Toast.makeText(context, "Move is invalid", Toast.LENGTH_SHORT).show()
                           }
                    ) {
                        Text(text = ""+grid[index], fontSize = 32.sp, color = Color.Black)
                    }
                }
            }
        }
    }
}


// initially make a random move for the computer and return
// the index of the move. Uf the board is full return -1
fun ComputerMove(board: MutableList<Char>): Int {
    var emptySlots = mutableListOf<Int>()

    for (i in 0..board.size-1) {
        if (board[i] == ' ')
            emptySlots.add(i)
    }

    // return one of the empty slots randomly, otherwise if it is empty return a -1
    if (emptySlots.isEmpty())
        return -1
    else
        return emptySlots.random()
}


fun displayGameOver(winner: Char, context: Context) {
    var message = "GAME OVER! "
    if (winner == '-')
        message += "It is a draw"
    else
        message += "$winner wins"

    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
}