package com.example.tictactoe_composableapp

/* Check if there was a winner and return 'X' or 'O' for the winner,
   otherwise it returns '-'.  */
fun checkWinner(board: MutableList<Char>): Char {
    var countX = 0  // how many consecutive Xs we have during a check in a row, col or diagonal
    var countO = 0  // how many consecutive Os we have during a check in a row, col or diagonal

    // check the rows first
    for (r in 0..2) {
        for (c in 0..2) {
            var index = row_col2Index(r, c)
            if (board[index] == 'X')
                ++countX
            else if (board[index] == 'O')
                ++countO
        }

        if (countX == 3)
            return 'X'
        else if (countO == 3)
            return 'O'

        countX = 0
        countO = 0
    }

    // check the columns for a winner
    for (c in 0..2) {
        for (r in 0..2) {
            var index = row_col2Index(r, c)
            if (board[index] == 'X')
                ++countX
            else if (board[index] == 'O')
                ++countO
        }

        if (countX == 3)
            return 'X'
        else if (countO == 3)
            return 'O'

        countX = 0
        countO = 0
    }

    // check top-left to bottom-right diagonal
    if (board[0] == board[4] && board[4] == board[8])
        // check that the diagonal cells are not empty
        if (board[0] == 'X' || board[0] == 'O')
            return board[0]

    // check top-right to bottom-left diagonal
    if (board[2] == board[4] && board[4] == board[6])
        // check that the diagonal cells are not empty
        if (board[2] == 'X' || board[2] == 'O')
            return board[2]

    // no winner
    return '-'
}


/* converts the row and column coordinates in the range [0,2]
   to a single index to access the 1-dimensional grid data structure
   which stores the tic-tac-toe board. Cell (0, 0) is mapped to 0,
   cell (0, 1) is mapped to 1 ... up to the last cell (2, 2) i.e.
   the last row and last column is mapped to 8 */
fun row_col2Index(row: Int, col: Int): Int {
    return row*3 + col
}