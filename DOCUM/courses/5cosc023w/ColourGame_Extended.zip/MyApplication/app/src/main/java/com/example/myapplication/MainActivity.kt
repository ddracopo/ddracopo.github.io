package com.example.myapplication

import android.content.SharedPreferences
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import java.util.*

class MainActivity : AppCompatActivity() {
    lateinit var prefs: SharedPreferences
    var colours = listOf(Color.BLACK, Color.BLUE, Color.RED, Color.GREEN, Color.WHITE, Color.YELLOW)
    var colours_str = listOf("BLACK", "BLUE", "RED", "GREEN", "WHITE", "YELLOW")
    var generator = Random()
    lateinit var bt: Button
    lateinit var bt2: Button
    lateinit var bt3: Button
    lateinit var tv: TextView
    var correct = 0 // number of correct answers
    var total = 0 // number of colours presented to the user
    var r = 0
    var second_colour:String? = ""  // the second random colour

    // this corresponds to either the left (if 0) or the right button (if 1)
    var correct_button = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // inflate the 3 buttons and the textview from XML
        bt = findViewById(R.id.button)
        bt2 = findViewById(R.id.button2)
        bt3 = findViewById(R.id.button3)
        tv = findViewById<TextView>(R.id.textView)

        // create the shared preferences object
        prefs =
            getSharedPreferences("uk.ac.westminster.sharedpreferenceslectureexample", MODE_PRIVATE)

        // restore the data
        total = prefs.getInt("total", 0)
        correct = prefs.getInt("correct", correct)

        // pickup the previous randomly generated number
        r = prefs.getInt("r", 0)
        correct_button = prefs.getInt("correct_button", 0)
        second_colour = prefs.getString("second_colour", "null")

        if (second_colour == "null") {
            nextGame(false)
            second_colour = colours_str.random()
            while (second_colour == colours_str[r])
                second_colour = colours_str.random()
        }
        else
            nextGame(true)
        // associate the 2 buttons with listeners
        bt2.setOnClickListener {
            ++total
            if (correct_button == 0) // left button contains the correct answerr
                ++correct
            tv.setText("Score: $correct/$total")
// present the user with a new colour
            nextGame(false)
        }

        bt3.setOnClickListener {
            ++total
            if (correct_button == 1) // right buttons contains the correct answer
                ++correct
            tv.setText("Score: $correct/$total")
// present the user with a new colour
            nextGame(false)
        }
    }

    /* what happens when the activity goes away
    * save tha data that I am interested in restoring later on*/
    override fun onPause() {
        super.onPause()
         /* give me the editor associated with the sharedpreferences
          object created in the onCreate() method */
        var editor = prefs.edit()
        // start saving the data - in this case I just save the score
        editor.putInt("total", total)
        editor.putInt("correct", correct)
        editor.putInt("r", r)
        editor.putInt("correct_button", correct_button)
        editor.putString("second_colour", second_colour)

        // persist the data
        editor.apply()
    }

    // argument is true if we would like to restore the state of the game
    fun nextGame(restore: Boolean) {
        tv.setText("Score: $correct/$total")


        // generate a random number in the range 0->5 if not restoring state
        if (!restore) {
            r = generator.nextInt(colours.size)

            // choose which button (left or right) contains the correct answer
            correct_button = generator.nextInt(2)

            // select the second random colour
            second_colour = colours_str.random()
            while (second_colour == colours_str[r])
                second_colour = colours_str.random()
        }

        // choose the corresponding colour from the colours list - i.e. the r-th element in the list
        var random_colour_chosen = colours[r]
        // set the colour of the top button to the random colour chosen
        bt.setBackgroundColor(random_colour_chosen)


        // if the correct answer corresponds to the left button
        if (correct_button == 0) {
            bt2.setText("" + colours_str[r])
            bt3.setText("" + second_colour)
        } else { // the right button contains the correct answer
            bt3.setText("" + colours_str[r])
            bt2.setText("" + second_colour)
        }
    }
}