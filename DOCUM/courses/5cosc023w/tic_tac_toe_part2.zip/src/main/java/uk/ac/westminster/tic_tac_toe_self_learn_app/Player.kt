package uk.ac.westminster.tic_tac_toe_self_learn_app

open class Player(var board: Board, var symbol: Char, var activity: MainActivity) {
    // symbol is an 'O' or 'X' depending on whether
    // this player playes with an 'X' or an 'O'

    /* decides on the next move for this player
       returns a list (x, y) corresponding to the next
       move of this player -
       The default implementation here picks up a random cell among
       all available ones */
    open fun play(): List<Int> {
        var random_cell = board.empty_cells.random()

        return random_cell
    }

}