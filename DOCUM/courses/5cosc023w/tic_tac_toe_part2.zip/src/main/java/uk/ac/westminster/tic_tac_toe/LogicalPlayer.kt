package uk.ac.westminster.tic_tac_toe

import android.util.Log
import android.widget.Toast

class LogicalPlayer(board: Board, symbol: Char, activity: MainActivity): Player(board, symbol, activity) {
    override fun play(): List<Int> {
        var chosen_cell  = get_winning_or_defend_cell()

        if (chosen_cell == null) {
            return super.play()
        }
        else
            return chosen_cell
    }


    /* if the player plays with symbol 'O':
       this will return a cell that it is either a winning move
       if there are already 2 Os in a row, column, diagonal
       or a defending move if there are already 2 Xs in a
       row, column, diagonal
       - similarly if the player plays with symbol 'X'
         winning corresponds to 2 Xs in a row, column, diagonal
         defense corresponds to 2 Os in a row, column, diagonal */
    fun get_winning_or_defend_cell(): List<Int>? {
        var countX = 0  // how many consecutive Xs we have during a check in a row, col or diagonal
        var countO = 0  // how many consecutive Os we have during a check in a row, col or diagonal

        var emptySlot: List<Int>? = null
        var winningSlot: List<Int>?? = null
        var defendSlot: List<Int>? = null

        // check in the rows
        for (x in 0..2) {
            for (y in 0..2) {
                if (board.grid[x][y].entry == 'X')
                    ++countX
                else if (board.grid[x][y].entry == 'O')
                    ++countO
                else  // empty cell
                    emptySlot = listOf(x, y)
            }

            // if a winning cell or defending cell was found note it down
            if (countX == 2 && emptySlot != null) {
                if (symbol == 'X')
                    winningSlot = emptySlot  // could return here but this will be done in the end
                else
                    defendSlot = emptySlot
            }
            else if (countO == 2 && emptySlot != null) {
                if (symbol == 'O')
                    winningSlot = emptySlot
                else
                    defendSlot = emptySlot
            }

            // reset counter values for the next row check
            countX = 0
            countO = 0
            emptySlot = null
        }

        // check in the columns
        countX = 0
        countO = 0
        emptySlot = null
        for (y in 0..2) {
            for (x in 0..2) {
                if (board.grid[x][y].entry == 'X')
                    ++countX
                else if (board.grid[x][y].entry == 'O')
                    ++countO
                else  // empty cell
                    emptySlot = listOf(x, y)
            }

            // if a winning cell or defending cell was found, note it down
            if (countX == 2 && emptySlot != null) {
                if (symbol == 'X')
                    winningSlot = emptySlot
                else
                    defendSlot = emptySlot
            } else if (countO == 2 && emptySlot != null) {
                if (symbol == 'O')
                    winningSlot = emptySlot
                else
                    defendSlot = emptySlot
            }

            // reset counter values for the next column check
            countX = 0
            countO = 0
            emptySlot = null
        }

        /* check the top-left to bottom-right diagonal */
        for (i in 0..2) {
            if (board.grid[i][i].entry == 'X')
                ++countX
            else if (board.grid[i][i].entry == 'O')
                ++countO
            else
                emptySlot = listOf(i, i)
        }

        // if a winning cell or defending cell was found, note it down
        if (countX == 2 && emptySlot != null) {
            if (symbol == 'X')
                winningSlot = emptySlot
            else
                defendSlot = emptySlot
        } else if (countO == 2 && emptySlot != null) {
            if (symbol == 'O')
                winningSlot = emptySlot
            else
                defendSlot = emptySlot
        }

        // reset counter values for the next column check
        countX = 0
        countO = 0
        emptySlot = null

        /*  check the top-right to bottom-left diagonal */
        var x = 2
        var y = 0
        for (i in 0..2) {
            if (board.grid[x - i][y + i].entry == 'X')
                ++countX
            else if (board.grid[x - i][y + i].entry == 'O')
                ++countO
            else
                emptySlot = listOf(x - i, y + i)
        }

        // if a winning cell or defending cell was found, note it down
        if (countX == 2 && emptySlot != null) {
            if (symbol == 'X')
                winningSlot = emptySlot
            else
                defendSlot = emptySlot
        }
        else if (countO == 2 && emptySlot != null) {
            if (symbol == 'O')
                winningSlot = emptySlot
            else
                defendSlot = emptySlot
        }

        // choose a winning move if found, or a defending one if one is possible
        if (winningSlot != null) {
            Toast.makeText(activity, "I win! Look at my move!", Toast.LENGTH_SHORT).show()
            //Log.d("***** WON *****", "won")
            return winningSlot
        }
        else if (defendSlot != null) {
            Toast.makeText(activity, "Defending myself!", Toast.LENGTH_SHORT).show()
            //Log.d("********** Defending ************", "defending myself")
            return defendSlot
        }
        else
            return null
    }
}