package uk.ac.westminster.tic_tac_toe_randomplayer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var bt1: Button = findViewById<Button>(R.id.bt1)
        var bt2: Button = findViewById<Button>(R.id.bt2)
        var bt3: Button = findViewById<Button>(R.id.bt3)
        var bt4: Button = findViewById<Button>(R.id.bt4)
        var bt5: Button = findViewById<Button>(R.id.bt5)
        var bt6: Button = findViewById<Button>(R.id.bt6)
        var bt7: Button = findViewById<Button>(R.id.bt7)
        var bt8: Button = findViewById<Button>(R.id.bt8)
        var bt9: Button = findViewById<Button>(R.id.bt9)

        /* a 2-dimensional structure holding all buttons (list of lists containing buttons)
           each of the inner lists represents one row of the grid
        */
        var buttons = listOf(listOf(bt1, bt2, bt3),
            listOf(bt4, bt5, bt6),
            listOf(bt7, bt8, bt9)
        )

        // create the internal representation of my board
        var board = Board()

        // create one object out of MyObjectListener
        val listener = MyButtonListener(board, buttons)

        // associate all the buttons with the same listener
        for (r in buttons)
            for (b in r)
                b.setOnClickListener(listener)

    }
}


class MyButtonListener(var board: Board, var buttons: List<List<Button>>) : View.OnClickListener {
    // properties board and buttons will be implicitly created because of the "var" above

    override fun onClick(v: View?) {
        var button: Button = v as Button

        // figure out at what position (x, y) the object button is located
        var x1: Int = 0
        var y1: Int = 0
        for (x in 0..2)
            for (y in 0..2)
                if (buttons[x][y] === button) {
                    x1 = x
                    y1 = y
                }

        // make the move corresponding to the user click only if the position is not taken
        if (listOf(x1, y1) in board.empty_cells ) {
            button.setText("X")
            // update the internal representation after the user clicks on a button
            board.move('X', x1, y1)

            /* Now it is the turn of the computer player
               Initially this is a naive player, it will only
               pick up a random cell among the available ones */
            if (!board.empty_cells.isEmpty()) {
                var random_cell = board.empty_cells.random()
                var x = random_cell[0]  // x is the row corresponding to the random cell chosen
                var y = random_cell[1]  // y is the row corresponding to the random cell chosen
                board.move('O', x, y)

                // update the graphical representation of the buttons as well
                buttons[x][y].setText("O")
            }
            else
                Toast.makeText(v?.context, "GAME OVER!!!!", Toast.LENGTH_LONG).show()
        }
        else
            Toast.makeText(v?.context, "Move is invalid", Toast.LENGTH_SHORT).show()
    }
}

