package uk.ac.westminster.tic_tac_toe_randomplayer

/* This represents a single square of the tic-tac-toe game */
class Cell {
    var entry: Char = ' '

    /* change the character in the square (cell)
       Returns true if success or false if changing the value failed
     */
    fun setValue(c: Char): Boolean {
        if (c == 'X' || c == 'O') {
            entry = c
            return true
        }
        else
            return false
    }
}


/* This represents the full grid of the game consisting of 3x3 cells */
class Board {

    // a 2-dimensional structure (list of lists of cells)
    var grid = listOf(listOf(Cell(), Cell(), Cell()),
                      listOf(Cell(), Cell(), Cell()),
                      listOf(Cell(), Cell(), Cell()),
    )

    /* This is a set of all squares which are currently empty in the grid
       The set contains elements of type (x, y). e.g. (2, 1) that means
       square in row 2 and col 1 is empty
     */
    var empty_cells = mutableSetOf<List<Int>>()

    init {
        for (x in 0..2)
            for (y in 0..2)
                empty_cells += listOf(x, y)
    }


    /* place char c at position (x,y) - player makes a move
       It returns true if the move succeeded or false otherwise */
    fun move(c: Char, x: Int, y: Int): Boolean {
        if (x in 0..2 && y in 0..2) {
            // update both structures to indicate that position (x, y) is taken
            empty_cells -= listOf(x, y)
            return grid[x][y].setValue(c)
        }
        else  // invalid move
            return false
    }

    /* Check if there was a winner and return 'X' or 'O' for the winner */
    fun checkWinner(): Char {
        var countX = 0  // how many consecutive Xs we have during a check in a row, col or diagonal
        var countO = 0  // how many consecutive Os we have during a check in a row, col or diagonal

        // check in the rows
        for (x in 0..2) {
            for (y in 0..2) {
                if (grid[x][y].entry == 'X')
                    ++countX
                else if (grid[x][y].entry == 'O')
                    ++countO
            }
            if (countX == 3)
                return 'X'
            else if (countO == 3)
                return 'O'

            countX = 0
            countO = 0
        }

        // check in the columns
        for (y in 0..2) {
            for (x in 0..2) {
                if (grid[x][y].entry == 'X')
                    ++countX
                else if (grid[x][y].entry == 'O')
                    ++countO
            }
            if (countX == 3)
                return 'X'
            else if (countO == 3)
                return 'O'

            countX = 0
            countO = 0
        }

        // check top-left to bottom-right diagonal
        if (grid[0][0].entry == grid[1][1].entry && grid[1][1].entry == grid[2][2].entry)
            if (grid[0][0].entry == 'X' || grid[0][0].entry == 'O')
                return grid[0][0].entry

        // check top-right to bottom-left diagonal
        if (grid[0][2].entry == grid[1][1].entry && grid[1][1].entry == grid[2][0].entry)
            if (grid[1][1].entry == 'X' || grid[1][1].entry == 'O')
                return grid[1][1].entry

        // no winner
        return '-'
    }
}