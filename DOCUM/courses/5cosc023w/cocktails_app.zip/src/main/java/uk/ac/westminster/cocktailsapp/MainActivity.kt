package uk.ac.westminster.cocktailsapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URL

class MainActivity : AppCompatActivity() {
    var tv: TextView? = null
    var edt: EditText? = null
    var bt: Button? = null

    var edt2: EditText? = null
    var picture_url: String? = null
    var bt2: Button? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tv = findViewById(R.id.tv)
        edt = findViewById(R.id.edt)
        bt = findViewById(R.id.getNames)
        edt2 = findViewById(R.id.edt2)
        bt2 = findViewById(R.id.getRecipe)

        // https://www.thecocktaildb.com/api/json/v1/1/filter.php?i=Vodka

        bt?.setOnClickListener {
            getNames()
        }

        bt2?.setOnClickListener {
            getRecipes()
        }
    }


    fun getNames() {
        val stb = StringBuilder("") // contains all json
        val stb2 = StringBuilder("") // contains all drink names

        runBlocking {
            launch {
                withContext(Dispatchers.IO) {
                    val ingredient_requested = edt?.text.toString()
                    val url = URL("https://www.thecocktaildb.com/api/json/v1/1/filter.php?i=" +
                               ingredient_requested.trim())
                    val con =  url.openConnection()
                    val bf = BufferedReader(InputStreamReader(con.getInputStream()))

                    // read all lines JSON info  in a stringbuilder
                    var line = bf.readLine()
                    while (line != null) {
                        stb.append(line)
                        line = bf.readLine()
                    }

                    // now do the JSON parsing
                    if (stb.toString() == "")
                        return@withContext

                    val json = JSONObject(stb.toString())
                    val jsonArray = json.getJSONArray("drinks")

                    // find the cocktail names entries and put them in stb2
                    for (i in 0..jsonArray.length()-1) {
                        val json_drink = jsonArray[i] as JSONObject
                        val cocktail_name = json_drink["strDrink"] as String
                        stb2.append(cocktail_name + "\n")
                    }
                }

                /* update the textview with the names of cocktails containing
                   the ingredient entered by the user */
                tv?.setText(stb2)
            }
        }

    }


    fun getRecipes() {
        val cocktail_requested = edt2?.text.toString()
        val i = Intent(this, MainActivity2::class.java)
        i.putExtra("name", cocktail_requested)
        startActivity(i)
    }
}