package uk.ac.westminster.cocktailsapp

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class MainActivity2 : AppCompatActivity() {
    var imgview: ImageView? = null
    var picture_url: String? = null
    var cocktail_name: String? = null
    var title: TextView? = null
    var tv2: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

        cocktail_name = intent.getStringExtra("name")
        imgview = findViewById(R.id.imgview)
        title = findViewById(R.id.title)
        tv2 = findViewById(R.id.tv2)
        title?.setText(cocktail_name)

        displayRecipePhoto()
    }


    fun displayRecipePhoto() {
        val stb = StringBuilder("")  // contains all JSON
        val recipe = StringBuilder("")  // contains the recipe extracted from JSON

        runBlocking {
            launch {
                withContext(Dispatchers.IO) {
                    val url = URL("https://www.thecocktaildb.com/api/json/v1/1/search.php?s=" +
                                  cocktail_name?.trim())
                    val con =  url.openConnection()
                    val bf = BufferedReader(InputStreamReader(con.getInputStream()))

                    // read all lines JSON info  in a stringbuilder
                    var line = bf.readLine()
                    while (line != null) {
                        stb.append(line + "\n")
                        line = bf.readLine()
                    }

                    /* do the JSON parsing */
                    val json = JSONObject(stb.toString())

                    //val jsonArray: JSONArray = json.getJSONArray("drinks")
                    var jsonArray = json["drinks"]

                    if (jsonArray is JSONArray) {
                        jsonArray = jsonArray as JSONArray

                        // find the matching cocktail name entry and extract recipe
                        for (i in 0..jsonArray.length() - 1) {
                            val json_drink = jsonArray.getJSONObject(i)
                            val cocktail_name = json_drink.getString("strDrink")
                            if (cocktail_name.lowercase() == cocktail_name.lowercase()) {
                                recipe.append(json_drink.getString("strInstructions"))
                                picture_url = json_drink.getString("strDrinkThumb")
                            }
                        }

                        val cocktail_picture: Bitmap = getBitmapPicture()

                        // set the text for the recipe
                        tv2?.setText(recipe)

                        // set the picture for the cocktail
                        imgview?.setImageBitmap(cocktail_picture)
                    }
                    else {  // deal with the case that the user requested a non-existing drink
                        tv2?.setText("Drink not found in DB!")
                    }
                }
            }

        }
    }


    // retrieve a bitmap image from the URL in JSON
    fun getBitmapPicture(): Bitmap {
        var bitmap: Bitmap? = null

        val url = URL(picture_url)
        val con = url.openConnection() as HttpURLConnection
        val bfstream = BufferedInputStream(con.inputStream)

        bitmap = BitmapFactory.decodeStream(bfstream)

        return bitmap
    }


}