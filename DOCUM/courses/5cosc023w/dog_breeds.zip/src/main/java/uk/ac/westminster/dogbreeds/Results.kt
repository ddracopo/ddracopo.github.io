package uk.ac.westminster.dogbreeds

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class Results : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_results)

        val correctTV = findViewById<TextView>(R.id.correct)
        val incorrectTV = findViewById<TextView>(R.id.incorrect)

        val correct = intent.getIntExtra("correct", 0)
        val incorrect = intent.getIntExtra("incorrect", 0)

        correctTV.setText("Correct answers: " + correct)
        incorrectTV.setText("Wrong answers: " + incorrect)

    }
}