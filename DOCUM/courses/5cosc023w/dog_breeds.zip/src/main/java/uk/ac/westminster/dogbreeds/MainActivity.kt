package uk.ac.westminster.dogbreeds

import android.content.Intent
import android.graphics.Color
import android.media.Image
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.core.view.isInvisible
import java.util.Random

class MainActivity : AppCompatActivity() {
    val drawable_ids = listOf<Int>(R.drawable.collie_03853, R.drawable.collie_03857,
                                   R.drawable.french_bulldog_04823, R.drawable.french_bulldog_04825,
                                   R.drawable.german_shepherd_dog_04959, R.drawable.german_shepherd_dog_04962,
                                   R.drawable.icelandic_sheepdog_05754, R.drawable.icelandic_sheepdog_05756,
                                   R.drawable.italian_greyhound_06156, R.drawable.italian_greyhound_06158,
                                   R.drawable.norwegian_buhund_07122, R.drawable.norwegian_buhund_07123,
                                   R.drawable.otterhound_07432, R.drawable.otterhound_07436,
                                   R.drawable.poodle_07954, R.drawable.poodle_07956,
                                   R.drawable.portuguese_water_dog_07988, R.drawable.portuguese_water_dog_07990,
                                   R.drawable.welsh_springer_spaniel_08242,
                                   R.drawable.welsh_springer_spaniel_08243)

    // breeds corresponding 1-to-1 to the drawable ids of images
    val breeds = listOf<String>("Collie", "Collie", "French bulldog", "French bulldog",
                                "German Shepherd", "German Shepherd", "Icelandic Sheepdog", "Icelandic Sheepdog",
                                "Italian Greyhound", "Italian Greyhound", "Norwegian Buhund", "Norwegian Buhund",
                                "Otrerhound", "Otrerhound", "Poodle", "Poodle",
                                "Portuguese Water", "Portuguese Water",
                                "Welsh Springer Spaniel", "Welsh Springer Spaniel")

    var correct = 0   // value for correct answers
    var incorrect = 0  //  value for incorrect answers

    lateinit var imgView1: ImageView
    lateinit var imgView2: ImageView
    lateinit var imgView3: ImageView
    lateinit var nextButton: Button
    lateinit var finishButton: Button
    lateinit var tv: TextView
    lateinit var message_tv: TextView

    lateinit var generator: Random

    var breed_choice: Int = 0
    var user_choice: Int = 0

    var imagesClickable = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // retrieve the 3 image views, the 2 buttons and the 2 text views
        imgView1 = findViewById<ImageView>(R.id.iv1)
        imgView2 = findViewById<ImageView>(R.id.iv2)
        imgView3 = findViewById<ImageView>(R.id.iv3)
        nextButton = findViewById<Button>(R.id.next_bt)
        finishButton = findViewById<Button>(R.id.finish_bt)
        tv = findViewById<TextView>(R.id.tv)
        message_tv = findViewById<TextView>(R.id.message_tv)

        generator =  Random()

        displayNewImages()

        // set the click listeners for the 3 image views
        imgView1.setOnClickListener {
            if (imagesClickable) {
                user_choice = 0
                message_tv.isInvisible = false
                Log.d("**** user_choice:*** ", "" + user_choice)
                if (user_choice == breed_choice) {
                    message_tv.setText("Correct!")
                    message_tv.setTextColor(Color.GREEN)
                    ++correct
                } else {
                    message_tv.setText("Wrong!")
                    message_tv.setTextColor(Color.RED)
                    ++incorrect
                }
            }

            // user cannot click again on the same set of images
            imagesClickable = false
        }


        imgView2.setOnClickListener {
            if (imagesClickable) {
                user_choice = 1
                message_tv.isInvisible = false
                Log.d("**** user_choice:*** ", "" + user_choice)
                if (user_choice == breed_choice) {
                    message_tv.setText("Correct!")
                    message_tv.setTextColor(Color.GREEN)
                    ++correct
                } else {
                    message_tv.setText("Wrong!")
                    message_tv.setTextColor(Color.RED)
                    ++incorrect
                }
            }

            // user cannot click again on the same set of images
            imagesClickable = false
        }

        imgView3.setOnClickListener {
            if (imagesClickable) {
                user_choice = 2
                message_tv.isInvisible = false
                Log.d("**** user_choice:*** ", "" + user_choice)
                if (user_choice == breed_choice) {
                    message_tv.setText("Correct!")
                    message_tv.setTextColor(Color.GREEN)
                    ++correct
                } else {
                    message_tv.setText("Wrong!")
                    message_tv.setTextColor(Color.RED)
                    ++incorrect
                }
            }

            // user cannot click again on the same set of images
            imagesClickable = false
        }

        nextButton.setOnClickListener {
            displayNewImages()
        }

        /* finish button -> Show results */
        finishButton.setOnClickListener {
            val i = Intent(this, Results::class.java)

            // intent carries the score with it
            i.putExtra("correct", correct)
            i.putExtra("incorrect", incorrect)

            // create the new activity
            startActivity(i)
        }

        //imgView1.setImageResource(R.drawable.brittany_02625)
        /*val resource: String = "brittany_02625"
        val resource_id = resources.getIdentifier(resource, "drawable", "uk.ac.westminster.dogbreeds")
        imgView1.setImageResource(resource_id) */
    }

    fun displayNewImages(): Unit {
        // make images clickable again
        imagesClickable = true

        // index in the arrays for first unique breed image
        val img1_index = generator.nextInt(breeds.size)
        val breed1 = breeds[img1_index]

        // index in the arrays for the second unique breed image
        var img2_index = generator.nextInt(breeds.size)
        var breed2 = breeds[img2_index]

        while (breed2.equals(breed1)) {
            img2_index = generator.nextInt(breeds.size)
            breed2 = breeds[img2_index]
        }

        // index in the arrays for the third unique breed image
        var img3_index = generator.nextInt(breeds.size)
        var breed3 = breeds[img3_index]

        while (breed3.equals(breed1) || breed3.equals(breed2)) {
            img3_index = generator.nextInt(breeds.size)
            breed3 = breeds[img3_index]
        }

        // place the chosen images in the image views
        imgView1.setImageResource(drawable_ids[img1_index])
        imgView2.setImageResource(drawable_ids[img2_index])
        imgView3.setImageResource(drawable_ids[img3_index])

        // make message textview invisible
        message_tv.isInvisible = true

        // set the textview for a random breed among the 3 displayed
        breed_choice = generator.nextInt(3)
        Log.d("**** breed_choice:*** ", ""+breed_choice)

        if (breed_choice == 0)
            tv.setText(breed1)
        else if (breed_choice == 1)
            tv.setText(breed2)
        else
            tv.setText(breed3)
    }

}