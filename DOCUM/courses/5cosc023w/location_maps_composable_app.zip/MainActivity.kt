package uk.ac.westminster.mapscomposableapp

import android.content.Intent
import android.content.pm.PackageManager
import android.location.Address
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

import java.util.Locale

class MainActivity : ComponentActivity() {
    lateinit var fusedLocationProviderClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GUI()
        }

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
    }

    fun getLocation(locationCallback: LocationCallback) {
        if (ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // if not granted, request the permission
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION),
                1
            )
        } else {  // permission has been granted
            var locationRequest =
                LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 10000L).build()
            fusedLocationProviderClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )

            // Example of how to get the last location now (without any periodic updates)
            fusedLocationProviderClient.lastLocation.addOnSuccessListener { location ->
                lastLocationToString(location)
            }
        }
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            fusedLocationProviderClient.lastLocation.addOnSuccessListener { location ->
                lastLocationToString(location)
            }
    }

    fun lastLocationToString(lastLocation: Location?): String {
        var tvLocationString = ""


        if (lastLocation != null) {
            var address: Address? = null

            var geocoder: Geocoder = Geocoder(this, Locale.getDefault())
            var addresses: List<Address> =
                geocoder.getFromLocation(lastLocation!!.latitude, lastLocation!!.longitude, 1) as List<Address>

            if (addresses != null && addresses.size > 0) {
                address = addresses[0]
            }

            tvLocationString = "Latitude: " + lastLocation!!.latitude + ", Longitude: " + lastLocation!!.longitude
            if (address != null)
                tvLocationString += address.toString()
        }
        else
            tvLocationString = "Location is not available"

        return tvLocationString
    }

    @Composable
    fun GUI() {
        var locationString by remember{ mutableStateOf("") }
        var currentLocation by remember{ mutableStateOf<Location?>(null) }

        var locationCallback: LocationCallback = remember{object : LocationCallback() {
            override fun onLocationResult(p0: LocationResult) {
                super.onLocationResult(p0)
                currentLocation = p0.lastLocation
                locationString = lastLocationToString(currentLocation)
            }
        }}


        Column {
            Text(text=locationString)
            Button(onClick = {
                getLocation(locationCallback)}
            ) {
                Text("Get Location")
            }
            Button(onClick = {
                showMap(currentLocation) }
            ) {
                Text("Show Map")
            }
        }


    }


    fun showMap(location: Location?) {
        var i = Intent(this, MapsActivity::class.java)
        i.putExtra("latitude", location?.latitude)
        i.putExtra("longitude", location?.longitude)
        startActivity(i)
    }
}

