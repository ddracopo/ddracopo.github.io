package com.example.lotteryfullapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.util.*


class MainActivity : AppCompatActivity() {
    // random generator object from Java - could use Kotlin Random instead
    var gen: Random = Random()

    /* declare textview properties (fields) as lateinit because we initialise
       them later inside onCreate() */
    lateinit var tv1: TextView
    lateinit var tv2: TextView
    lateinit var tv3: TextView
    lateinit var tv4: TextView
    lateinit var tv5: TextView
    lateinit var tv6: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var button = findViewById<Button>(R.id.bt)
        //var results = findViewById<TextView>(R.id.tv)

        /*button.setOnClickListener {
            calculateResults(results)
        }*/

        tv1 = findViewById<TextView>(R.id.tv1)
        tv2 = findViewById<TextView>(R.id.tv2)
        tv3 = findViewById<TextView>(R.id.tv3)
        tv4 = findViewById<TextView>(R.id.tv4)
        tv5 = findViewById<TextView>(R.id.tv5)
        tv6 = findViewById<TextView>(R.id.tv6)

        var excluded = findViewById<EditText>(R.id.excluded)

        var res = mutableListOf<Int>()

        button.setOnClickListener {
            var excluded_string = excluded.text.toString()
            calculateResults(tv1, tv2, tv3, tv4, tv5, tv6, excluded_string, res)
        }

        var r1 = findViewById<Button>(R.id.r1)
        var r2 = findViewById<Button>(R.id.r2)
        var r3 = findViewById<Button>(R.id.r3)
        var r4 = findViewById<Button>(R.id.r4)
        var r5 = findViewById<Button>(R.id.r5)
        var r6 = findViewById<Button>(R.id.r6)

        r1.setOnClickListener {
            var excluded_string = excluded.text.toString()
            replaceNumber(tv1, res, excluded_string)
        }

        r2.setOnClickListener {
            var excluded_string = excluded.text.toString()
            replaceNumber(tv2, res, excluded_string)
        }

        r3.setOnClickListener {
            var excluded_string = excluded.text.toString()
            replaceNumber(tv3, res, excluded_string)
        }

        r4.setOnClickListener {
            var excluded_string = excluded.text.toString()
            replaceNumber(tv4, res, excluded_string)
        }

        r5.setOnClickListener {
            var excluded_string = excluded.text.toString()
            replaceNumber(tv5, res, excluded_string)
        }

        r6.setOnClickListener {
            var excluded_string = excluded.text.toString()
            replaceNumber(tv6, res, excluded_string)
        }
    }

    fun calculateResults(tv1: TextView, tv2: TextView, tv3: TextView, tv4: TextView, tv5: TextView, tv6: TextView, excluded_string: String, res:MutableList<Int>) {
        // reset the previous generated results
        res.clear()

        // split the string based on spaces as demiliter
        var excluded_list = excluded_string.split("\\s+".toRegex())
        var excluded_numbers = mutableListOf<Int>()
        for (i in excluded_list) {
            if (i.trim() != "")   // check if nothing is entered in the excluded textbox
                excluded_numbers.add(i.trim().toInt())
        }

        // random generator object from Java - could use Kotlin Random instead
        //var gen: Random = Random()

        while (res.size < 6) {
            var number = 1 + gen.nextInt(49)
            if (number !in res && number !in excluded_numbers)   // check that the number is not already there
                res.add(number)
        }

        // populate the textviews
        tv1.setText(res[0].toString())
        tv2.setText("" + res[1])
        tv3.setText("" + res[2])
        tv4.setText("" + res[3])
        tv5.setText("" + res[4])
        tv6.setText("" + res[5])
    }


    // replace the result in the first argument textview with a new unique number
    fun replaceNumber(tv: TextView, res:MutableList<Int>, excluded_string: String) {
        // make sure that generate numbers has been called at least once so that the results is not empty
        if (res.size == 0)
            return

        // split the string based on spaces as demiliter
        var excluded_list = excluded_string.split("\\s+".toRegex())
        var excluded_numbers = mutableListOf<Int>()
        for (i in excluded_list) {
            if (i.trim() != "")   // check if nothing is entered in the excluded textbox
                excluded_numbers.add(i.trim().toInt())
        }

        var previous_number = tv.text.toString().trim().toInt()

        var number = 1 + gen.nextInt(49)
        while (number == previous_number || number in res || number in excluded_numbers) {
            number = 1 + gen.nextInt(49)
        }

        tv.setText(number.toString())
        // replace the previous number in the previously generated list
        var index = res.indexOf(previous_number)
        res[index] = number
    }

    // this is just for Task 1
    /*fun calculateResults(results: TextView) {
        var res = mutableListOf<Int>()

        // random generator object from Java - could use Kotlin Random instead
        var gen: Random = Random()

        while (res.size < 6) {
            var number = 1 + gen.nextInt(49)
            if (number !in res)   // check that the number is not already there
                res.add(number)
        }

        results.setText("")
        for (n in res)
            results.append("" + n + "  ")
    } */
}