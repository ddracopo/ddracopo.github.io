package uk.ac.westminster.theweatherapp

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.*

class MainActivity : AppCompatActivity() {
    var tv: TextView? = null
    var edt: EditText? = null
    var MY_API_KEY: String? = null
    var url_string: String? = null
    var button: Button? = null
    var history_button: Button? = null
    var imgView: ImageView? = null

    var city_name: String? = null
    var temp: String? = null
    var date_time: Date? = null  // the date time of the data fetched

    var bitMapIcon: Bitmap? = null

    // the url string for the icon representing the current weather
    var icon: String? = null

    // the DAO for interacting with the city database
    lateinit var cityDao: CityDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // inflate the views from XML
        tv = findViewById(R.id.tv)
        button = findViewById(R.id.button)
        history_button = findViewById(R.id.history_button)
        edt = findViewById(R.id.edt)
        imgView = findViewById(R.id.imgView)

        MY_API_KEY = resources.getString(R.string.MY_API_KEY)

        button?.setOnClickListener {
            getWeather()
        }

        history_button?.setOnClickListener {
            getHistory()
        }


        // create the database
        val db = Room.databaseBuilder(this, AppDatabase::class.java, "myCityDB").build()
        cityDao = db.cityDao()
    }

    // fetch the weather for the user entered city from the Web service
    fun getWeather() {
        val city = edt!!.text.toString().trim()
        if (city == "")
            return

        url_string =
            "https://api.openweathermap.org/data/2.5/weather?q=$city&units=metric&appid=$MY_API_KEY"

        var data: String = ""

        // start the fetching of data in the background
        runBlocking {
            withContext(Dispatchers.IO) {
                // this will contain the whole of JSON
                val stb = StringBuilder("")

                val url = URL(url_string)
                val con = url.openConnection() as HttpURLConnection
                val bf: BufferedReader
                try {
                    bf = BufferedReader(InputStreamReader(con.inputStream))
                }
                catch (e: IOException) {
                    e.printStackTrace()
                    return@withContext
                }

                var line = bf.readLine()
                while (line != null) {
                    stb.append(line)
                    line = bf.readLine()
                }

                // pick up all the data
                data = parseJSON(stb)

                // pick up the icon as well
                bitMapIcon = getBitmapPicture()

                // save data to database
                var cal: Calendar = Calendar.getInstance()
                cal.setTime(date_time)
                val day = cal.get(Calendar.DAY_OF_MONTH)
                val month = cal.get(Calendar.MONTH)
                val year = cal.get(Calendar.YEAR)
                val hours = cal.get(Calendar.HOUR_OF_DAY)
                val minutes = cal.get(Calendar.MINUTE)
                val seconds = cal.get(Calendar.SECOND)

                val city = City("" + day + "/" + month + "/" + year + " $hours:$minutes:$seconds", city_name, temp)
                cityDao.insertCity(city)
                Log.d("*****", "" + day + "/" + month + "/" + year + " $hours:$minutes:$seconds")
            }

            // display the data
            tv?.setText(data)
            imgView?.setImageBitmap(bitMapIcon)
        }
    }


    // extracts the relevant info from the JSON returned by the Web Service
    fun parseJSON(stb: StringBuilder): String {
        var description: String? = null

        var sunrise: Int = 0
        var sunset: Int = 0
        var sunrise_date: Date? = null
        var sunset_date: Date? = null

        // extract the actual data
        val json = JSONObject(stb.toString())
        val json_main = json.getJSONObject("main")
        val json_sys = json.getJSONObject("sys")
        sunrise = json_sys["sunrise"] as Int
        sunrise_date = Date(sunrise * 1000L)

        sunset = json_sys["sunset"] as Int
        sunset_date = Date(sunset * 1000L)

        date_time = Date((json["dt"] as Int)*1000L)

        temp = json_main.getString("temp")
        val feels_like = json_main["feels_like"]

        val jarray = json.getJSONArray("weather")
        val weather_json = jarray.getJSONObject(0)
        description = weather_json["description"] as String
        icon = weather_json["icon"] as String

        city_name = json["name"] as String

        var all_info = "" + city_name + ": " + temp + "\n"
        all_info += "Status: " + description +
                "\nFeels like: " + feels_like +
                "\n" + "Sunrise: " + sunrise_date +
                "\n" + "Sunset: " + sunset_date

        return all_info
    }


    // retrieve a bitmap image from the URL in JSON
    fun getBitmapPicture(): Bitmap {
        var bitmap: Bitmap? = null

        // "http://openweathermap.org/img/wn/10d@2x.png"
        val url = URL("https://openweathermap.org/img/wn/" + icon + "@2x.png")
        val con = url.openConnection() as HttpURLConnection
        val bfstream = BufferedInputStream(con.inputStream)

        bitmap = BitmapFactory.decodeStream(bfstream)

        return bitmap
    }


    fun getHistory() {
        var city_list: List<City>
        runBlocking {
            withContext(Dispatchers.IO) {
                city_list = cityDao.getAll(city_name)
            }
        }

        var city_arrayList = ArrayList<String>()
        for (c in city_list)
            city_arrayList.add(c.date + "   temp: " + c.temperature)

        val i = Intent(this, HistoryActivity::class.java)
        i.putStringArrayListExtra("city_list", city_arrayList)
        i.putExtra("city_name", city_name)
        startActivity(i)
    }
}