package uk.ac.westminster.theweatherapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class HistoryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val tv = findViewById<TextView>(R.id.tv)
        val city_tv = findViewById<TextView>(R.id.city_tv)
        val city_arraylist = intent.getStringArrayListExtra("city_list")
        val city_name = intent.getStringExtra("city_name")
        var result = ""

        if (city_arraylist != null) {
            for (c in city_arraylist) {
                result += c + "\n"
            }
        }

        tv.setText(result)
        city_tv.setText(city_name)
    }
}