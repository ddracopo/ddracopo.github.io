package uk.ac.westminster.theweatherapp

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class City (
    @PrimaryKey val date: String,

    val city_name: String?,
    val temperature: String?
)
