package uk.ac.westminster.memorygame

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TableLayout
import android.widget.TextView
import androidx.core.view.children
import androidx.core.view.isInvisible
import androidx.core.view.iterator
import java.util.*

class MainActivity : AppCompatActivity() {
    // actual grid size - this will vary from game to fame
    var rows = 5
    var cols = 5

    var score_total = 0  // total answers given
    var score_correct = 0  // total correct answers given by the user

    // the 2-dimensional list of lists holding a reference to all buttons
    lateinit var buttons:MutableList<MutableList<Button>>
    lateinit var generator: Random

    /* the specific buttons which have been displayed as green to the user
       at the start of each game
     */
    var presented_buttons: MutableList<Button> = mutableListOf()

    // Button listener
    lateinit var listener: MyListener

    // how many green cells will be presented to the user in the start of each game
    var random_cells = 6

    lateinit var tblLayout:TableLayout
    lateinit var score_tv:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // The textview displaying the score
        score_tv = findViewById(R.id.score_tv)

        generator = Random()

        // 2-dimensional list of buttons
        buttons = mutableListOf()

        /*for (row in 1..rows) {
            var row: MutableList<Button> = mutableListOf<Button>()
            for (col in 1..cols) {
                row.add(Button(this))
            }
            buttons.add(row)
        } */

        // get the button views from XML
        initialise_buttons()

        // generate a new game
        displayNewGame()

    }

    fun displayNewGame() {
        // choose a random grid size: 5x5, 5x4, 4x5, 4x4, 4x3, 3x4, 5x3, 3x5
        val n = generator.nextInt(3)
        val m = generator.nextInt(3)
        rows = 3 + n
        cols = 3 + m

        Log.d("****(n, m)*****", "" + rows + ", " + cols)

        // make all the buttons grey and with empty text and all visible
        for (row in 0..rows-1)
            for (col in 0..cols-1) {
                buttons[row][col].setBackgroundColor(Color.argb(255, 128, 128, 128))
                buttons[row][col].setText("")
                buttons[row][col].isInvisible = false
            }

        /*  make the rest of the buttons (if any) invisible */
        // first make the columns invisible
        for (row in 0..rows-1)
            for (col in cols..4)
                buttons[row][col].isInvisible = true

        // then make the rows invisible
        for (row in rows..4)
            for (col in 0..4)
                buttons[row][col].isInvisible = true

        presented_buttons.clear()

        // how many green buttons have been generated randomly so far
        var count = 0

        while (count < random_cells) {
            // choose some random cells to be displayed as green
            var row = generator.nextInt(rows)
            var col = generator.nextInt(cols)

            Log.d("****(row, col)*****", "" + row + ", " + col)

            // if the button is not chosen and presented as green before
            if (buttons[row][col] !in presented_buttons) {
                ++count
                presented_buttons.add(buttons[row][col])

                // make the button green
                buttons[row][col].setBackgroundColor(Color.argb(255, 0, 128, 0))
            }
        }

        // reset the listener maybe this is the 2nd, 3rd,..., nth new game
        listener.reset(presented_buttons)

        // display randomly selected in green colour for only 3 seconds
        val timer = object: CountDownTimer(3000, 1000) {
            override fun onTick(millisUntilFinished: Long) {

            }

            override fun onFinish() {
                for (row in 0..rows-1)
                    for (col in 0..cols-1) {
                        buttons[row][col].setBackgroundColor(Color.argb(255, 128, 128, 128))
                        buttons[row][col].setText("")
                    }
            }
        }
        timer.start()
    }


    fun initialise_buttons(): Unit {
        listener = MyListener(presented_buttons, this)

        // inflate table layout object from XML
        tblLayout = findViewById<TableLayout>(R.id.tblLayout)

        // Alternative way to populate 22-dimensional data structure buttons
        /*buttons[0][0] = findViewById<Button>(R.id.bt11)
        buttons[0][0].setOnClickListener(listener)

        buttons[0][1] = findViewById<Button>(R.id.bt12)
        buttons[0][1].setOnClickListener(listener)

        buttons[0][2] = findViewById<Button>(R.id.bt13)
        buttons[0][2].setOnClickListener(listener)

        buttons[0][3] = findViewById<Button>(R.id.bt14)
        buttons[0][3].setOnClickListener(listener)

        buttons[0][4] = findViewById<Button>(R.id.bt15)
        buttons[0][4].setOnClickListener(listener)

        buttons[1][0] = findViewById<Button>(R.id.bt21)
        buttons[1][0].setOnClickListener(listener)

        buttons[1][1] = findViewById<Button>(R.id.bt22)
        buttons[1][1].setOnClickListener(listener)

        buttons[1][2] = findViewById<Button>(R.id.bt23)
        buttons[1][2].setOnClickListener(listener)

        buttons[1][3] = findViewById<Button>(R.id.bt24)
        buttons[1][3].setOnClickListener(listener)

        buttons[1][4] = findViewById<Button>(R.id.bt25)
        buttons[1][4].setOnClickListener(listener)

        buttons[2][0] = findViewById<Button>(R.id.bt31)
        buttons[2][0].setOnClickListener(listener)

        buttons[2][1] = findViewById<Button>(R.id.bt32)
        buttons[2][1].setOnClickListener(listener)

        buttons[2][2] = findViewById<Button>(R.id.bt33)
        buttons[2][2].setOnClickListener(listener)

        buttons[2][3] = findViewById<Button>(R.id.bt34)
        buttons[2][3].setOnClickListener(listener)

        buttons[2][4] = findViewById<Button>(R.id.bt35)
        buttons[2][4].setOnClickListener(listener)

        buttons[3][0] = findViewById<Button>(R.id.bt41)
        buttons[3][0].setOnClickListener(listener)

        buttons[3][1] = findViewById<Button>(R.id.bt42)
        buttons[3][1].setOnClickListener(listener)

        buttons[3][2] = findViewById<Button>(R.id.bt43)
        buttons[3][2].setOnClickListener(listener)

        buttons[3][3] = findViewById<Button>(R.id.bt44)
        buttons[3][3].setOnClickListener(listener)

        buttons[3][4] = findViewById<Button>(R.id.bt45)
        buttons[3][4].setOnClickListener(listener)

        buttons[4][0] = findViewById<Button>(R.id.bt51)
        buttons[4][0].setOnClickListener(listener)

        buttons[4][1] = findViewById<Button>(R.id.bt52)
        buttons[4][1].setOnClickListener(listener)

        buttons[4][2] = findViewById<Button>(R.id.bt53)
        buttons[4][2].setOnClickListener(listener)

        buttons[4][3] = findViewById<Button>(R.id.bt54)
        buttons[4][3].setOnClickListener(listener)

        buttons[4][4] = findViewById<Button>(R.id.bt55)
        buttons[4][4].setOnClickListener(listener) */

        // for each row
        /*for (r in 0..tblLayout.childCount-1) {
            var row: ViewGroup = tblLayout.getChildAt(r) as ViewGroup

            for (c in 0..row.childCount-1) {
                buttons[r][c] = row.getChildAt(c) as Button
                buttons[r][c] .setOnClickListener(listener)
            }
        }*/

        // populate the buttons 2-dimensional data structure - Elegant Dynamic way
        for (r in tblLayout.children) {  // for each row r
            val row = mutableListOf<Button>()
            for (b in (r as ViewGroup).children) {  // for each button b
                b.setOnClickListener(listener)
                row.add(b as Button)
            }
            buttons.add(row)
        }
    }


    /* Updates the score - it is called from the listener of the button
       The argument indicates if a correct answer was given (1) and 0
       if an incorrect guess was made
     */
    fun updateScore(correct: Int) {
        ++score_total
        score_correct = score_correct + correct

        // display the score
        score_tv.setText("Score: " + score_correct + "/" + score_total)
    }
}


// Listener class for all buttons
class MyListener(presented_buttons: MutableList<Button>, activity: MainActivity) : View.OnClickListener {
    lateinit var presented_buttons: MutableList<Button>
    lateinit var activity: MainActivity  // the creator activity used for callbacks
    var clicks = 0  // how many user clicks so far

    var score_total = 0
    var score_correct = 0

    init {
        this.presented_buttons = presented_buttons
        this.activity = activity
    }

    override fun onClick(v: View?) {
        // the user can only click a limited number of times equal to the number of green cells
        if (clicks < presented_buttons.size) {
            if (v in presented_buttons) {
                v?.setBackgroundColor(Color.argb(255, 0, 128, 0))
                activity.updateScore(1)
            }
            else {  // display as red
                v?.setBackgroundColor(Color.argb(255, 255, 12, 0))
                if (v is Button) {
                    v?.setText("X")
                    v?.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 14.0f)  // 14dp is the textSize
                }
                activity.updateScore(0)
            }

            ++clicks  // one more user click
        }
        else {
            activity.displayNewGame()
        }
    }

    /* Reset to 0 number of clicks and re-set the newly presented green cells
       Also preserve the previous score
     */
    fun reset(presented_buttons: MutableList<Button>) {
        clicks = 0
        this.presented_buttons = presented_buttons
    }
}


