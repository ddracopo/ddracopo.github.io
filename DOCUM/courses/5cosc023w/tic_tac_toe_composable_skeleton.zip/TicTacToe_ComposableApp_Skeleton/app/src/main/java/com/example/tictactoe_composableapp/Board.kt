package com.example.tictactoe_composableapp

/* Check if there was a winner and return 'X' or 'O' for the winner,
   otherwise it returns '-'.*/
fun checkWinner(board: MutableList<Char>): Char {
    /*** TODO *****/

    // no winner
    return '-'
}


/* converts the row and column coordinates in the range [0,2]
   to a single index to access the 1-dimensional grid data structure
   which stores the tic-tac-toe board. Cell (0, 0) is mapped to 0,
   cell (0, 1) is mapped to 1 ... up to the last cell (2, 2) i.e.
   the last row and last column is mapped to 8 */
fun row_col2Index(row: Int, col: Int): Int {
    return row*3 + col
}